<!-- resources/views/partials/footer.blade.php -->
<footer class="fixed bottom-0 right-0 sm:ml-64 z-20 w-[calc(100%-16rem)] bg-white border-t border-gray-200 shadow-sm transition-all duration-300 ease-in-out">
    <div class="p-4 md:py-6">
        <div class="text-center">
            <span class="text-sm text-gray-500">
                © <?php echo e(date('Y')); ?> <a href="#" class="hover:underline">Portal TPB by Neo Telemetri</a>. All Rights Reserved.
            </span>
        </div>
       
    </div>
</footer><?php /**PATH /Users/leadsi/Documents/nouval/Neo Telemetri/Project/projectTPB/resources/views/partials/footer.blade.php ENDPATH**/ ?>