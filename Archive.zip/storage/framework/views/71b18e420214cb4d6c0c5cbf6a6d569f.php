<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['paginator']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['paginator']); ?>
<?php foreach (array_filter((['paginator']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<?php if(isset($paginator) && method_exists($paginator, 'hasPages') && $paginator->hasPages()): ?>
    <nav class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mt-4">
        <div class="text-sm text-gray-700 mb-2 sm:mb-0">
            <?php if(method_exists($paginator, 'total')): ?>
                Menampilkan <?php echo e($paginator->firstItem()); ?> sampai <?php echo e($paginator->lastItem()); ?> dari <?php echo e($paginator->total()); ?> data
            <?php else: ?>
                Menampilkan data halaman <?php echo e($paginator->currentPage()); ?>

            <?php endif; ?>
        </div>
        <div>
            <ul class="inline-flex items-center -space-x-px">
                
                <?php if($paginator->onFirstPage()): ?>
                    <li>
                        <span class="px-3 py-2 ml-0 leading-tight text-gray-400 bg-white border border-gray-300 rounded-l-lg cursor-not-allowed">&lt;</span>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="px-3 py-2 ml-0 leading-tight text-gray-500 bg-white border border-gray-300 rounded-l-lg hover:bg-gray-100 hover:text-gray-700">&lt;</a>
                    </li>
                <?php endif; ?>

                
                <?php if(method_exists($paginator, 'elements')): ?>
                    <?php $__currentLoopData = $paginator->elements(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(is_string($element)): ?>
                            <li>
                                <span class="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300"><?php echo e($element); ?></span>
                            </li>
                        <?php endif; ?>
                        <?php if(is_array($element)): ?>
                            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $paginator->currentPage()): ?>
                                    <li>
                                        <span class="px-3 py-2 leading-tight text-white bg-amber-600 border border-amber-600"><?php echo e($page); ?></span>
                                    </li>
                                <?php else: ?>
                                    <li>
                                        <a href="<?php echo e($url); ?>" class="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700"><?php echo e($page); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    
                    <li>
                        <span class="px-3 py-2 leading-tight text-white bg-amber-600 border border-amber-600"><?php echo e($paginator->currentPage()); ?></span>
                    </li>
                <?php endif; ?>

                
                <?php if($paginator->hasMorePages()): ?>
                    <li>
                        <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 rounded-r-lg hover:bg-gray-100 hover:text-gray-700">&gt;</a>
                    </li>
                <?php else: ?>
                    <li>
                        <span class="px-3 py-2 leading-tight text-gray-400 bg-white border border-gray-300 rounded-r-lg cursor-not-allowed">&gt;</span>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
<?php endif; ?><?php /**PATH /Users/leadsi/Documents/nouval/Neo Telemetri/Project/projectTPB/resources/views/components/pagination.blade.php ENDPATH**/ ?>